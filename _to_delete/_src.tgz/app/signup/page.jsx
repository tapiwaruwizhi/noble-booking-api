"use client";

// app/signup/page.jsx
//
// The landing page for the emailed "create your account" link.
//
// ── Why it lives on the API domain and not in Framer ────────────────────────
// The session cookie is httpOnly + Secure + SameSite=None and is set on THIS
// origin. Signing up here means the cookie is already in place by the time the
// person clicks "Continue to your account" — no token in a URL, nothing to
// hand over, nothing for Framer to implement.
//
// ── The email field is display-only ─────────────────────────────────────────
// The address comes back from GET /api/auth/signup and is rendered read-only.
// It is NOT posted back; the server takes it from the signed token. Making it
// editable would turn this into an open account-creation form (see the route).
//
// Deliberately no Tailwind classes: this page is the only thing on the API
// domain a client will ever look at, and a self-contained <style> block means
// it can't be broken by a future change to globals.css.

import { useEffect, useState } from "react";

const PORTAL_FALLBACK = "https://noblevetclinic.com";

export default function SignupPage() {
  const [phase, setPhase]   = useState("checking"); // checking | form | done | dead
  const [token, setToken]   = useState("");
  const [email, setEmail]   = useState("");
  const [first, setFirst]   = useState("");
  const [last, setLast]     = useState("");
  const [phone, setPhone]   = useState("");
  const [error, setError]   = useState("");
  const [deadMsg, setDead]  = useState("");
  const [busy, setBusy]     = useState(false);
  const [name, setName]     = useState("");
  const [portal, setPortal] = useState(PORTAL_FALLBACK);

  // Read the token from the URL directly rather than via useSearchParams, which
  // would drag a Suspense boundary in for no benefit on a page this small.
  useEffect(() => {
    const t = new URLSearchParams(window.location.search).get("token") || "";
    setToken(t);
    if (!t) {
      setDead("That link is missing its code. Open the link from your email again, or enter your email address in the app to get a new one.");
      setPhase("dead");
      return;
    }
    let alive = true;
    (async () => {
      try {
        const res  = await fetch(`/api/auth/signup?token=${encodeURIComponent(t)}`);
        const data = await res.json().catch(() => ({}));
        if (!alive) return;
        if (data?.valid) {
          setEmail(data.email || "");
          if (data.portal_url) setPortal(data.portal_url);
          setPhase("form");
        } else {
          setDead(data?.message || "This link is no longer valid.");
          setPhase("dead");
        }
      } catch {
        if (!alive) return;
        // A network failure is not a dead link — say so, and let them retry.
        setDead("We couldn't check this link just now. Check your connection and reload the page.");
        setPhase("dead");
      }
    })();
    return () => { alive = false; };
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    if (busy) return;
    if (!first.trim()) { setError("Please enter your first name."); return; }
    if (!phone.trim()) { setError("Please enter a phone number."); return; }
    setError(""); setBusy(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          token,
          first_name: first.trim(),
          last_name:  last.trim(),
          phone:      phone.trim(),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        // 409 = the account already exists. That's not a form error to correct,
        // it's a different next step, so it gets the dead-end screen with the
        // "go and sign in" wording rather than a red line under a field.
        if (res.status === 409) { setDead(data?.error || "You already have an account."); setPhase("dead"); return; }
        setError(data?.error || "Something went wrong. Please try again.");
        return;
      }
      setName(data?.firstName || first.trim());
      if (data?.portal_url) setPortal(data.portal_url);
      setPhase("done");
    } catch {
      setError("We couldn't reach the clinic just now. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="wrap">
      <style>{CSS}</style>

      <div className="card">
        <div className="brand">
          <div className="mark">Noble</div>
          <div className="sub">Veterinary Clinics</div>
        </div>

        {phase === "checking" && (
          <p className="muted center">Checking your link…</p>
        )}

        {phase === "dead" && (
          <>
            <h1>We can't use that link</h1>
            <p className="muted">{deadMsg}</p>
            <a className="btn ghost" href={portal}>Back to Noble Vet Clinics</a>
          </>
        )}

        {phase === "form" && (
          <form onSubmit={submit} noValidate>
            <h1>Create your account</h1>
            <p className="muted">
              We don't have a record for this email address yet. Tell us who you
              are and we'll set you up.
            </p>

            <label className="lbl">Email address</label>
            <div className="fixed" title="This is the address we emailed your link to">
              {email}
              <span className="lock" aria-hidden="true">🔒</span>
            </div>
            <p className="hint">
              This is the address your link was sent to, so it can't be changed here.
            </p>

            <div className="row">
              <div>
                <label className="lbl" htmlFor="first">First name</label>
                <input id="first" className="in" value={first} autoComplete="given-name"
                       onChange={(e) => { setFirst(e.target.value); setError(""); }} />
              </div>
              <div>
                <label className="lbl" htmlFor="last">Last name</label>
                <input id="last" className="in" value={last} autoComplete="family-name"
                       onChange={(e) => { setLast(e.target.value); setError(""); }} />
              </div>
            </div>

            <label className="lbl" htmlFor="phone">Mobile number</label>
            <input id="phone" className="in" value={phone} inputMode="tel" autoComplete="tel"
                   placeholder="+971 50 123 4567"
                   onChange={(e) => { setPhone(e.target.value); setError(""); }} />
            <p className="hint">So the clinic can reach you about appointments.</p>

            {error && <p className="err" role="alert">{error}</p>}

            <button className="btn" type="submit" disabled={busy}>
              {busy ? "Creating your account…" : "Create account"}
            </button>
          </form>
        )}

        {phase === "done" && (
          <>
            <div className="tick" aria-hidden="true">✓</div>
            <h1>You're all set{name ? `, ${name}` : ""}</h1>
            <p className="muted">
              Your account is ready and you're signed in. You can book
              appointments, add your pets and see your visit history.
            </p>
            <a className="btn" href={portal}>Continue to your account</a>
            <p className="hint center">
              Using the Noble Vet app? Open it and sign in with{" "}
              <strong>{email}</strong> — we'll send you a code.
            </p>
          </>
        )}
      </div>

      <p className="foot">Noble Veterinary Clinics · Dubai</p>
    </main>
  );
}

const CSS = `
  .wrap {
    min-height: 100vh; background: #F4F6F9;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    padding: 32px 16px;
    font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
    color: #14171C;
  }
  .card {
    width: 100%; max-width: 440px; background: #fff; border: 1px solid #E6E9EF;
    border-radius: 18px; padding: 32px 28px;
  }
  .brand { text-align: center; margin-bottom: 26px; }
  .mark { font-family: Georgia, 'Times New Roman', serif; font-size: 34px; line-height: 1; }
  .sub  { font-size: 11px; letter-spacing: .18em; text-transform: uppercase; color: #6B7280; margin-top: 6px; }
  h1    { font-family: Georgia, 'Times New Roman', serif; font-size: 24px; font-weight: 400; margin: 0 0 8px; }
  .muted { font-size: 14.5px; line-height: 1.55; color: #4B5563; margin: 0 0 22px; }
  .center { text-align: center; }
  .lbl  { display: block; font-size: 12.5px; font-weight: 600; color: #374151; margin: 0 0 6px; }
  .in {
    width: 100%; box-sizing: border-box; font: inherit; font-size: 15px;
    padding: 12px 14px; border: 1px solid #D8DDE6; border-radius: 12px; background: #fff; color: #14171C;
  }
  .in:focus { outline: none; border-color: #2465B4; box-shadow: 0 0 0 3px rgba(36,101,180,.14); }
  .fixed {
    display: flex; align-items: center; justify-content: space-between; gap: 10px;
    font-size: 15px; padding: 12px 14px; border: 1px solid #E6E9EF; border-radius: 12px;
    background: #F4F6F9; color: #4B5563; word-break: break-all;
  }
  .lock { opacity: .5; font-size: 13px; flex: none; }
  .hint { font-size: 12.5px; color: #6B7280; margin: 6px 0 18px; line-height: 1.5; }
  .row  { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
  .row .lbl { margin-bottom: 6px; }
  .err  { font-size: 13.5px; color: #B42318; background: #FEF3F2; border: 1px solid #FDA29B;
          border-radius: 10px; padding: 10px 12px; margin: 0 0 16px; }
  .btn {
    display: block; width: 100%; box-sizing: border-box; text-align: center; text-decoration: none;
    font: inherit; font-size: 15px; font-weight: 600; color: #fff; background: #2465B4;
    border: 1px solid #2465B4; border-radius: 999px; padding: 14px 20px; cursor: pointer; margin-top: 4px;
  }
  .btn:hover { background: #1D5397; }
  .btn:disabled { opacity: .6; cursor: default; }
  .btn.ghost { background: #fff; color: #2465B4; }
  .btn.ghost:hover { background: #EAF1FA; }
  .tick {
    width: 52px; height: 52px; border-radius: 50%; background: #EAF1FA; color: #2465B4;
    display: flex; align-items: center; justify-content: center; font-size: 26px; margin: 0 0 18px;
  }
  .foot { font-size: 12px; color: #9AA1AC; margin-top: 22px; }
  @media (max-width: 420px) {
    .card { padding: 26px 20px; }
    .row  { grid-template-columns: 1fr; }
  }
`;
