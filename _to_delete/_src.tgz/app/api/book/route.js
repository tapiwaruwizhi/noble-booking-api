// src/app/api/book/route.js
// POST /api/book
// Uses v2 throughout for all ezyVet API calls (v2 returns uid, v1 does not)

import { NextResponse } from "next/server";
import { getAccessToken } from "../../../lib/ezyvet/auth";

const CORS         = process.env.ALLOWED_ORIGIN ?? "*";
const BOOKING_BASE = process.env.EZYVET_EZYCAB_BASE_URL ?? "https://apiv2.trial.ezyvet.com";

export async function POST(req) {
  try {
    const body = await req.json();
    const {
      email, owner_name, owner_phone,
      contact_id:  existingContactId,
      contact_uid: existingContactUid,
      animal_id:   existingAnimalId,
      animal_uid:  existingAnimalUid,
      new_pet,
      appt_type_uid,
      resource_uid,
      start_time,
      start_iso,
      end_time,
      duration,
      description,
    } = body;

    console.log("═══════════════════════════════════════");
    console.log("[/api/book] STEP 0 — incoming payload:");
    console.log(JSON.stringify({ email, owner_name, owner_phone,
      existingContactId, existingContactUid,
      existingAnimalId, existingAnimalUid,
      new_pet, appt_type_uid, resource_uid,
      start_time, start_iso, end_time, duration, description,
    }, null, 2));

    const token    = await getAccessToken();
    const base     = process.env.EZYVET_BASE_URL;
    const authJson = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

    console.log("[/api/book] Token obtained ✓");
    console.log("[/api/book] base:", base, "| booking:", BOOKING_BASE);

    let contact_id  = existingContactId;
    let contact_uid = existingContactUid;
    let animal_id   = existingAnimalId;
    let animal_uid  = existingAnimalUid;

    // ── STEP 1: Create contact if new (v2) ───────────────────────────────────
    if (!contact_id && !contact_uid) {
      console.log("─────────────────────────────────────────");
      console.log("[/api/book] STEP 1 — creating new contact via v2...");
      const [first, ...rest] = (owner_name ?? "").trim().split(" ");
      const contactPayload = {
        first_name:  first,
        last_name:   rest.join(" ") || "-",
        is_customer: 1,
        contact_detail_list: [
          ...(email ? [{ name: "Email",  value: email,        type_id: 1, preferred: 1 }] : []),
          ...(owner_phone ? [{ name: "Mobile", value: owner_phone, type_id: 3, preferred: 0 }] : []),
        ],
      };
      console.log("[/api/book] Contact payload:", JSON.stringify(contactPayload));

      const cRes  = await fetch(`${base}/v2/contact`, {
        method: "POST", headers: authJson,
        body: JSON.stringify(contactPayload),
      });
      const cText = await cRes.text();
      console.log("[/api/book] Contact create status:", cRes.status);
      console.log("[/api/book] Contact create response:", cText);

      if (!cRes.ok) {
        return NextResponse.json({ error: "Failed to create contact", step: "create_contact", status: cRes.status, detail: cText }, { status: 502 });
      }

      const cData = JSON.parse(cText);
      const c     = cData.items?.[0]?.contact ?? cData.contact;
      contact_id  = c?.id;
      contact_uid = c?.uid;
      console.log("[/api/book] Contact created — id:", contact_id, "uid:", contact_uid);

      if (!contact_id) {
        return NextResponse.json({ error: "Contact created but no ID returned", step: "create_contact", detail: cData }, { status: 502 });
      }
    } else {
      console.log("[/api/book] STEP 1 — using existing contact id:", contact_id, "uid:", contact_uid);
    }

    // ── STEP 2: Create animal if new (v2) ────────────────────────────────────
    if (!animal_id && !animal_uid && new_pet) {
      console.log("─────────────────────────────────────────");
      console.log("[/api/book] STEP 2 — creating new animal via v2...");
      const animalPayload = {
        name:       new_pet.name,
        contact_id: contact_id,
        species:    new_pet.species ?? "Dog",
        breed:      new_pet.breed   ?? "",
        active:     1,
      };
      console.log("[/api/book] Animal payload:", JSON.stringify(animalPayload));

      const aRes  = await fetch(`${base}/v1/animal`, {
        method: "POST", headers: authJson,
        body: JSON.stringify(animalPayload),
      });
      const aText = await aRes.text();
      console.log("[/api/book] Animal create status:", aRes.status);
      console.log("[/api/book] Animal create response:", aText);

      if (!aRes.ok) {
        return NextResponse.json({ error: "Failed to create animal", step: "create_animal", status: aRes.status, detail: aText }, { status: 502 });
      }

      const aData = JSON.parse(aText);
      const a     = aData.items?.[0]?.animal ?? aData.animal;
      animal_id   = a?.id;
      animal_uid  = a?.uid;
      console.log("[/api/book] Animal created — id:", animal_id, "uid:", animal_uid);

      if (!animal_id) {
        return NextResponse.json({ error: "Animal created but no ID returned", step: "create_animal", detail: aData }, { status: 502 });
      }
    } else {
      console.log("[/api/book] STEP 2 — using existing animal id:", animal_id, "uid:", animal_uid);
    }

    // ── STEP 3: Build startTime ───────────────────────────────────────────────
    console.log("─────────────────────────────────────────");
    console.log("[/api/book] STEP 3 — building startTime...");
    const startTimeISO = start_iso
      ?? (start_time ? new Date(start_time * 1000).toISOString() : null);
    console.log("[/api/book] startTimeISO:", startTimeISO);

    if (!startTimeISO) {
      return NextResponse.json({ error: "start_time or start_iso is required", step: "build_start_time" }, { status: 400 });
    }

    let durationMinutes = duration ?? 30;
    if (!duration && start_time && end_time) {
      durationMinutes = Math.round((end_time - start_time) / 60);
    }
    console.log("[/api/book] durationMinutes:", durationMinutes);

    // ── STEP 4: Resolve UIDs via v2 (v1 does not return uid) ─────────────────
    console.log("─────────────────────────────────────────");
    console.log("[/api/book] STEP 4 — resolving UIDs via v2");
    console.log("[/api/book] contact_id:", contact_id, "| contact_uid:", contact_uid);
    console.log("[/api/book] animal_id:", animal_id, "| animal_uid:", animal_uid);

    if (!contact_uid && contact_id) {
      console.log("[/api/book] Fetching contact uid via v2 for id:", contact_id);
      const cRes  = await fetch(`${base}/v2/contact?id=${contact_id}&limit=1`, { headers: authJson });
      const cText = await cRes.text();
      console.log("[/api/book] Contact v2 status:", cRes.status);
      console.log("[/api/book] Contact v2 response:", cText);
      const cData = JSON.parse(cText);
      const c     = cData.items?.[0]?.contact ?? cData.contact;
      contact_uid = c?.uid;
      console.log("[/api/book] Resolved contact_uid:", contact_uid);
    }

    if (!animal_uid && animal_id) {
      console.log("[/api/book] Fetching animal uid via v2 for id:", animal_id);
      const aRes  = await fetch(`${base}/v2/animal?id=${animal_id}&limit=1`, { headers: authJson });
      const aText = await aRes.text();
      console.log("[/api/book] Animal v2 status:", aRes.status);
      console.log("[/api/book] Animal v2 response:", aText);
      const aData = JSON.parse(aText);
      const a     = aData.items?.[0]?.animal ?? aData.animal;
      animal_uid  = a?.uid;
      console.log("[/api/book] Resolved animal_uid:", animal_uid);
    }

    if (!contact_uid) {
      console.error("[/api/book] ✗ Could not resolve contact UID");
      return NextResponse.json({ error: "Could not resolve contact UID", step: "resolve_uids", contact_id }, { status: 502 });
    }
    if (!animal_uid) {
      console.error("[/api/book] ✗ Could not resolve animal UID");
      return NextResponse.json({ error: "Could not resolve animal UID", step: "resolve_uids", animal_id }, { status: 502 });
    }

    console.log("[/api/book] ✓ UIDs resolved — contact_uid:", contact_uid, "| animal_uid:", animal_uid);

    // ── STEP 5: POST /ezycab/booking ─────────────────────────────────────────
    console.log("─────────────────────────────────────────");
    console.log("[/api/book] STEP 5 — posting booking...");

    // Generate the reference BEFORE booking so it can be embedded in the
    // description — this makes it searchable directly inside ezyVet by staff,
    // not just a cosmetic string shown to the customer.
    const ref = `NVC-${Date.now().toString(36).slice(-4)}${Math.random().toString(36).slice(2, 4)}`.toUpperCase();
    const baseDescription = description ?? "Online booking via Noble Vet website";
    const fullDescription = `${baseDescription} | Ref: ${ref}`;

    const bookPayload = {
      startTime:           startTimeISO,
      type:                appt_type_uid,
      durationMinutes:     durationMinutes,
      appointmentStatus:   "unconfirmed",
      description:         fullDescription,
      animal:              animal_uid,
      contact:             contact_uid,
      provider:            resource_uid,
      additionalResources: [resource_uid],
    };

    console.log("[/api/book] Booking reference generated:", ref);
    console.log("[/api/book] Booking URL:", `${BOOKING_BASE}/ezycab/booking`);
    console.log("[/api/book] Booking payload:", JSON.stringify(bookPayload, null, 2));

    const bookRes  = await fetch(`${BOOKING_BASE}/ezycab/booking`, {
      method: "POST", headers: authJson,
      body: JSON.stringify(bookPayload),
    });
    const bookText = await bookRes.text();
    console.log("[/api/book] Booking status:", bookRes.status);
    console.log("[/api/book] Booking response:", bookText);

    if (!bookRes.ok) {
      return NextResponse.json({ error: "Booking failed", step: "create_booking", status: bookRes.status, detail: bookText }, { status: 502 });
    }

    const bookData = JSON.parse(bookText);
    const appt     = bookData.data?.[0] ?? bookData.appointment ?? bookData;
    const apptId   = appt?.id ?? appt?.uid;

    console.log("[/api/book] ✓ Booking successful — ref:", ref, "apptId:", apptId);
    console.log("═══════════════════════════════════════");

    const r = NextResponse.json({ success: true, appointment_uid: apptId, contact_uid, animal_uid, reference: ref });
    r.headers.set("Access-Control-Allow-Origin", CORS);
    return r;

  } catch (err) {
    console.error("[/api/book] UNCAUGHT ERROR:", err);
    return NextResponse.json({ error: "Internal server error", detail: err.message }, { status: 500 });
  }
}

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin":  process.env.ALLOWED_ORIGIN ?? "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}